import type { DeepPartial, Theme } from 'stream-chat-react-native';

// Read more about style customizations at - https://getstream.io/chat/react-native-chat/tutorial/#custom-styles
const streamTheme: DeepPartial<Theme> = {};

export { streamTheme };
